<?php
require_once('SessionFunctions.php');
StartGame();
?>
<META HTTP-EQUIV="REFRESH" CONTENT="0;URL=level1.php">
